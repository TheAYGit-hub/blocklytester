[Home](../README.md)

# blockly-svelte-sample [![Built on Blockly](https://tinyurl.com/built-on-blockly)](https://github.com/google/blockly)

This sample shows how to load Blockly in a [Svelte](https://svelte.dev) project.

## Running the sample

### Installation

```
npm install
```

### Running

start [Rollup](https://rollupjs.org) by:

```bash
npm run start
```

### Browse

Navigate to [http://localhost:3000/](http://localhost:3000/)
